import type { LucideIcon } from 'lucide-react'
import { NavLink, Outlet } from 'react-router'
import { brand } from '../lib/brand'

export type NavItem = { to: string; label: string; icon: LucideIcon; end?: boolean }

function Logo() {
  return (
    <span className="flex items-center gap-2 font-semibold tracking-tight">
      <span aria-hidden className="grid size-7 place-items-center rounded-md bg-primary text-sm text-white">
        {brand.name[0]}
      </span>
      {brand.name}
    </span>
  )
}

const links = (items: NavItem[], cls: (active: boolean) => string, iconCls: string) =>
  items.map(({ to, label, icon: Icon, end }) => (
    <NavLink key={to} to={to} end={end} className={({ isActive }) => cls(isActive)}>
      <Icon className={iconCls} aria-hidden />
      {label}
    </NavLink>
  ))

export function AppShell({ area, items }: { area: string; items: NavItem[] }) {
  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[15rem_1fr]">
      <a
        href="#conteudo"
        className="sr-only focus:not-sr-only focus:fixed focus:left-2 focus:top-2 focus:z-50 focus:rounded-md focus:bg-surface focus:px-3 focus:py-2"
      >
        Pular para o conteúdo
      </a>

      {/* Desktop: barra lateral */}
      <aside className="hidden border-r border-line bg-surface p-4 lg:sticky lg:top-0 lg:flex lg:h-dvh lg:flex-col lg:gap-6">
        <Logo />
        <nav aria-label={`Navegação: ${area}`} className="flex flex-col gap-1">
          {links(
            items,
            (on) =>
              `flex h-10 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors ${
                on ? 'bg-primary/10 text-primary' : 'text-muted hover:bg-canvas hover:text-ink'
              }`,
            'size-4',
          )}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-col pb-20 lg:pb-0">
        <header className="flex h-14 items-center justify-between border-b border-line bg-surface px-4 lg:px-8">
          <span className="lg:hidden">
            <Logo />
          </span>
          <span className="text-sm text-muted">{area}</span>
        </header>
        <p role="status" className="border-b border-l-2 border-line border-l-warning bg-surface px-4 py-2 text-xs text-ink lg:px-8">
          Pré-visualização sem login. A proteção de rotas entra na Fase 3.
        </p>
        <main id="conteudo" className="mx-auto w-full max-w-5xl flex-1 px-4 py-6 lg:px-8">
          <Outlet />
        </main>
      </div>

      {/* Celular: abas inferiores (toque mínimo de 56 px) */}
      <nav
        aria-label={`Navegação: ${area}`}
        className="fixed inset-x-0 bottom-0 z-20 grid border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden"
        style={{ gridTemplateColumns: `repeat(${items.length}, minmax(0, 1fr))` }}
      >
        {links(
          items,
          (on) =>
            `flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
              on ? 'text-primary' : 'text-muted'
            }`,
          'size-5',
        )}
      </nav>
    </div>
  )
}
