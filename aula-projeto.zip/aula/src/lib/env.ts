import { z } from 'zod'

const schema = z.object({
  VITE_SUPABASE_URL: z.string().url(),
  VITE_SUPABASE_PUBLISHABLE_KEY: z.string().min(20),
})

/** Recusa chave secreta (service_role / sb_secret_) no frontend. */
function ehChaveSecreta(chave: string): boolean {
  if (chave.startsWith('sb_secret_')) return true
  try {
    const payload = chave.split('.')[1]?.replace(/-/g, '+').replace(/_/g, '/') ?? ''
    return JSON.parse(atob(payload)).role === 'service_role'
  } catch {
    return false
  }
}

// Ainda não usado: entra na Fase 3, com o cliente Supabase.
export function carregarEnv() {
  const env = schema.parse(import.meta.env)
  if (ehChaveSecreta(env.VITE_SUPABASE_PUBLISHABLE_KEY)) {
    throw new Error('Chave secreta no frontend. Use somente a chave pública.')
  }
  return env
}
