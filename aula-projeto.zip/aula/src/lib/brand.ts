// Nome provisório. Ao trocar, altere também <title> em index.html.
export const brand = { name: 'Aula' } as const
