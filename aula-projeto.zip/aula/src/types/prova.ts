export type Situacao = 'disponivel' | 'em_andamento' | 'concluida'

export type Prova = {
  id: string
  titulo: string
  disciplina: string
  duracaoMin: number
  prazo: string // ISO 8601
  situacao: Situacao
  instrucoes: string
}
