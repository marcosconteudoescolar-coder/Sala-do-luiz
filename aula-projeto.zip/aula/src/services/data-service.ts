import type { Prova } from '../types/prova'

// Contrato único de acesso a dados. Na Fase 3 entra a implementação Supabase;
// as telas não mudam.
export interface DataService {
  listarProvas(): Promise<Prova[]>
}

// DEMONSTRAÇÃO: dados fictícios, só em memória. Nada é salvo nem tem nota.
const hora = 3_600_000
const em = (h: number) => new Date(Date.now() + h * hora).toISOString()

const dados: Prova[] = [
  {
    id: 'demo-1',
    titulo: 'Prova de Matemática: funções',
    disciplina: 'Matemática',
    duracaoMin: 50,
    prazo: em(48),
    situacao: 'disponivel',
    instrucoes: 'Individual, sem consulta. Você tem 50 minutos depois de iniciar.',
  },
  {
    id: 'demo-2',
    titulo: 'Interpretação de texto',
    disciplina: 'Língua Portuguesa',
    duracaoMin: 40,
    prazo: em(6),
    situacao: 'em_andamento',
    instrucoes: 'Suas respostas são salvas durante a prova. Entregue antes do prazo.',
  },
  {
    id: 'demo-3',
    titulo: 'Revolução Industrial',
    disciplina: 'História',
    duracaoMin: 30,
    prazo: em(-72),
    situacao: 'concluida',
    instrucoes: 'Prova encerrada. A correção aparece quando o professor liberar.',
  },
]

export const demoService: DataService = {
  listarProvas: () => new Promise((resolve) => setTimeout(() => resolve(dados), 400)),
}
