import { Clock, Inbox, TriangleAlert } from 'lucide-react'
import { useEffect, useState } from 'react'
import { demoService } from '../services/data-service'
import type { Prova, Situacao } from '../types/prova'

type Estado = { tipo: 'carregando' } | { tipo: 'erro' } | { tipo: 'pronto'; provas: Prova[] }

const secoes: { situacao: Situacao; titulo: string; vazio: string }[] = [
  { situacao: 'em_andamento', titulo: 'Em andamento', vazio: 'Nenhuma prova em andamento.' },
  { situacao: 'disponivel', titulo: 'Disponíveis', vazio: 'Nenhuma prova disponível agora.' },
  { situacao: 'concluida', titulo: 'Concluídas', vazio: 'Você ainda não concluiu nenhuma prova.' },
]

const rotulo: Record<Situacao, string> = {
  disponivel: 'Disponível',
  em_andamento: 'Em andamento',
  concluida: 'Concluída',
}

const cor: Record<Situacao, string> = {
  disponivel: 'text-primary bg-primary/10',
  em_andamento: 'text-ink border border-warning',
  concluida: 'text-success bg-success/10',
}

const data = new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' })

function CartaoProva({ prova }: { prova: Prova }) {
  return (
    <li className="flex flex-col gap-3 rounded-lg border border-line bg-surface p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-medium">{prova.titulo}</h3>
          <p className="text-sm text-muted">{prova.disciplina}</p>
        </div>
        <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-medium ${cor[prova.situacao]}`}>
          {rotulo[prova.situacao]}
        </span>
      </div>
      <p className="flex items-center gap-1.5 text-sm text-muted">
        <Clock className="size-4" aria-hidden />
        {prova.duracaoMin} min · prazo {data.format(new Date(prova.prazo))}
      </p>
      <p className="text-sm">{prova.instrucoes}</p>
      {prova.situacao !== 'concluida' && (
        <div>
          <button
            type="button"
            disabled
            className="min-h-11 rounded-md bg-primary px-4 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-50"
          >
            {prova.situacao === 'em_andamento' ? 'Continuar' : 'Iniciar'}
          </button>
          <p className="mt-1 text-xs text-muted">Indisponível: a realização de provas entra na Fase 4.</p>
        </div>
      )}
    </li>
  )
}

function Carregando() {
  return (
    <div aria-busy="true" aria-label="Carregando provas" className="flex flex-col gap-3">
      {[0, 1, 2].map((i) => (
        <div key={i} className="h-28 animate-pulse rounded-lg border border-line bg-surface" />
      ))}
    </div>
  )
}

export function PortalAluno() {
  const [estado, setEstado] = useState<Estado>({ tipo: 'carregando' })
  const [tentativa, setTentativa] = useState(0)

  useEffect(() => {
    let ativo = true
    demoService
      .listarProvas()
      .then((provas) => ativo && setEstado({ tipo: 'pronto', provas }))
      .catch(() => ativo && setEstado({ tipo: 'erro' }))
    return () => {
      ativo = false
    }
  }, [tentativa])

  function recarregar() {
    setEstado({ tipo: 'carregando' })
    setTentativa((n) => n + 1)
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-semibold tracking-tight">Olá!</h1>
        <p className="text-sm text-muted">Dados fictícios de demonstração. Nada é salvo.</p>
      </div>

      {estado.tipo === 'carregando' && <Carregando />}

      {estado.tipo === 'erro' && (
        <div role="alert" className="flex flex-col items-start gap-3 rounded-lg border border-line bg-surface p-4">
          <p className="flex items-center gap-2 text-sm font-medium">
            <TriangleAlert className="size-4 text-warning" aria-hidden />
            Não foi possível carregar as provas.
          </p>
          <button type="button" onClick={recarregar} className="min-h-11 rounded-md border border-line px-4 text-sm font-medium">
            Tentar de novo
          </button>
        </div>
      )}

      {estado.tipo === 'pronto' &&
        secoes.map(({ situacao, titulo, vazio }) => {
          const lista = estado.provas.filter((p) => p.situacao === situacao)
          return (
            <section key={situacao} aria-labelledby={`s-${situacao}`} className="flex flex-col gap-3">
              <h2 id={`s-${situacao}`} className="text-sm font-semibold">
                {titulo} <span className="font-normal text-muted">({lista.length})</span>
              </h2>
              {lista.length === 0 ? (
                <p className="flex items-center gap-2 rounded-lg border border-dashed border-line bg-surface px-4 py-6 text-sm text-muted">
                  <Inbox className="size-4" aria-hidden />
                  {vazio}
                </p>
              ) : (
                <ul className="flex flex-col gap-3">
                  {lista.map((p) => (
                    <CartaoProva key={p.id} prova={p} />
                  ))}
                </ul>
              )}
            </section>
          )
        })}
    </div>
  )
}
