# Aula — Arquitetura (Fase 1)

Status: plano. Nada aqui foi executado (sem rede no ambiente de geração).

## 1. Arquitetura

```
Navegador (React SPA estática)          Supabase
 • só chave pública                ──▶   Auth (convite; cadastro aberto desligado)
 • Zod valida entradas                   Postgres + RLS + funções RPC (SECURITY DEFINER)
 • toda escrita crítica via RPC          pg_cron: tick dos bots, varredura de prazos e sessões
                                         Realtime: painel do professor
                                         Edge Function: só convites (service role fica no servidor)
```

Regra: o frontend nunca escreve direto em `attempts`, `room_participants`, `monitoring_events` nem em respostas de tentativa encerrada. Só chama RPCs.

## 2. Estrutura de arquivos

```
aula/
  docs/                 ARQUITETURA.md, PUBLICACAO.md (Fase 7)
  supabase/migrations/  esquema, RLS, funções
  supabase/tests/       testes SQL (RLS, capacidade, concorrência)
  src/
    components/         shell, ui
    features/           auth, portal, provas, sala, fiscalizacao
    services/           DataService (interface) + demo/ + supabase/
    lib/                brand.ts, env.ts, tempo-servidor.ts
```

## 3. Modelo de dados

| Tabela | Pontos-chave |
|---|---|
| profiles | id = auth.users.id; `role` (student/teacher/admin) sem UPDATE pelo usuário |
| subjects, classes*, class_members* | *acréscimo: sem turmas, "avaliação autorizada" não tem definição |
| assessments | professor, duração, `opens_at`/`closes_at`, status, `reveal_key_at` |
| questions, answer_options | `answer_options` **sem** `is_correct` |
| question_keys* | gabarito em tabela própria, só professor (RLS filtra linhas, não colunas) |
| rooms | `capacity` 1–30, `bots_enabled`, `bot_seed`; várias salas por prova |
| room_participants | `seat_no` 1–30, `kind` real/bot, `profile_id` nulo p/ bots, `released_at`, `is_synthetic`, `unique(id,is_synthetic)` |
| attempts | `participant_id`, `expires_at` calculado no servidor, status, `unique(assessment_id, participant_id)` |
| responses | PK (attempt, question), `revision` monotônica |
| monitoring_events | append-only; `server_ts`; FK composta (participant_id, is_synthetic) |
| suspicion_scores*, review_records | fatores em JSON + `model_version`; revisão humana, sem efeito automático |
| notifications*, audit_log* | retenção: proposta a validar com responsável LGPD |

Invariantes estruturais:
- `unique (room_id, seat_no) where released_at is null` com `seat_no between 1 and 30`: estourar a sala é impossível, até por bug.
- FK composta com `is_synthetic`: evento/resposta sintético nunca aponta para aluno real.
- Notas e histórico leem só `is_synthetic = false`.

## 4. Salas e bots

- Ocupação = assento (`released_at is null`), não conexão. Aluno com prova em andamento mantém o assento mesmo offline.
- `entrar_sala(room_id)`: uma transação com `pg_advisory_xact_lock(room)`. Reconexão devolve o mesmo assento; senão menor assento livre; se cheia, libera o bot mais antigo (`joined_at`, `id`) e ocupa o assento; sem bots, erro `ROOM_FULL`. Nunca remove aluno real. Idempotente por (sala, perfil).
- Bots são linhas, avançadas por `tick_bots` (pg_cron) com PRNG determinístico por (semente, bot, passo). Sem processos.
- Desligar: libera todos os bots (`bots_off`), preserva alunos reais. Dados sintéticos continuam marcados.
- Heartbeat 20 s; 90 s sem sinal = `disconnected`; sem prova iniciada e 5 min offline = assento liberado (valores propostos).

## 5. Provas

- `iniciar_tentativa`: `expires_at = least(now()+duração, closes_at)`.
- `salvar_resposta`: rejeita revisão antiga e escrita após `expires_at`.
- Tempo esgotado: o servidor finaliza com o que está salvo (`expired`), de forma preguiçosa e por varredura.
- `entregar_tentativa`: idempotente.
- Relógio do cliente = offset do servidor, só visual. Indicador salvo / salvando / não salvo; fila local é buffer, não fonte da verdade.
- Questões só visíveis com tentativa em andamento; gabarito só após `reveal_key_at`.

## 6. Autenticação

- Cadastro público desligado; convites por Edge Function.
- Papel em `profiles.role` lido por helper SECURITY DEFINER. Nunca `user_metadata`.
- Primeiro professor: função única `bootstrap_primeiro_professor(email)` no SQL editor; recusa se já existir professor.
- Projetos separados `aula-dev` e `aula-prod`; contas de teste só em dev.
- Limite de login: limites nativos do Auth + CAPTCHA. Bloqueio por conta depende do plano: verificar.

## 7. Fiscalização

- Eventos do navegador podem ser forjados ou omitidos: entram só por RPC com lista permitida, taxa limitada e `server_ts`.
- Pontuação explicável: fatores com peso e evidência. Dados sintéticos pontuados à parte, rotulados "validação do detector".
- Nenhuma função ou gatilho altera tentativa ou nota a partir da pontuação (teste obrigatório).

## 8. Riscos e dependências

- Limites do plano gratuito do Supabase (pg_cron, Edge Functions, Realtime, pausa por inatividade): confirmar.
- Turmas com mais de 30 alunos: premissa de várias salas por prova.
- Foco no celular dispara por ligação ou notificação: falso positivo esperado.
- LGPD e menores: revisão antes de alunos reais. Fonte Inter hospedada localmente (sem requisição a terceiros).
- Contraste: "Atenção" #B86B12 dá ≈4,1:1 sobre branco, abaixo de 4,5:1. Só em borda, ícone ou texto grande.

## 9. Fases

1 plano (este arquivo) · 2 fundação visual (shell pronto; telas com dados demonstrativos a seguir) · 3 backend · 4 provas · 5 salas e bots · 6 fiscalização · 7 verificação.

## 10. .env.example

```
VITE_SUPABASE_URL=
VITE_SUPABASE_PUBLISHABLE_KEY=   # só a chave pública; nunca service_role / sb_secret_
```
